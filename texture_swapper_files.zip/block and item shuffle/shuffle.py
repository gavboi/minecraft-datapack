# imports
import os
import shutil
import zipfile
import random

# -----------------------------------

# variables n stuff
a_path = os.path.dirname(os.path.realpath(__file__))
block_path = a_path + "\\unshuffled assets\\minecraft\\textures\\block\\" 
block_path_new = a_path + "\\assets\\minecraft\\textures\\block\\"
item_path = a_path + "\\unshuffled assets\\minecraft\\textures\\item\\"
item_path_new = a_path + "\\assets\\minecraft\\textures\\item\\"
blocks = []
blocks_new = []
items = []
items_new = []

# -----------------------------------

print("Shuffling blocks...")
            
# getting names for needed files (blocks)
for file in os.listdir(block_path):
    if file[-3:] == "png":
        blocks.append(file)
        blocks_new.append(file)

# copying with new names (blocks)
for file in blocks:
        shutil.copy(block_path + file,block_path_new + blocks_new[random.randint(0,len(blocks_new)-1)])

# -----------------------------------

print("Done!\nShuffling items...")

# getting names for needed files (items)
for file in os.listdir(item_path):
    if file[-3:] == "png":
        items.append(file)
        items_new.append(file)

# copying with new names (items)
for file in items:
        shutil.copy(item_path + file,item_path_new + items_new[random.randint(0,len(items_new)-1)])

# -----------------------------------

print("Done!\nZipping files...")

# create zip
zipObj = zipfile.ZipFile("shuffled.zip","w")

# add files to zip
zipObj.write("pack.png")
zipObj.write("pack.mcmeta")
zipObj.write("assets\\minecraft\\textures\\colormap\\foliage.png")
zipObj.write("assets\\minecraft\\textures\\colormap\\grass.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_0.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_1.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_2.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_3.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_4.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_5.png")
zipObj.write("assets\\minecraft\\textures\\gui\\title\\background\\panorama_overlay.png")
for file in os.listdir(block_path_new):
    zipObj.write("assets\\minecraft\\textures\\block\\" + file)
for file in os.listdir(item_path_new):
    zipObj.write("assets\\minecraft\\textures\\item\\" + file)

zipObj.close()

# -----------------------------------

input("Finished! ('Enter' to exit...)")


