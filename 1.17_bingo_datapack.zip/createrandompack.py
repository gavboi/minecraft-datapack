print('Preparing...')

# ---imports---

import os, random, shutil, fileinput, zipfile, time

# ---variables---

main_path = os.path.dirname(os.path.realpath(__file__))
sou_path = os.path.join(main_path, 'assets/advbank')
dest_path = os.path.join(main_path, 'data/bingo/advancements')
zip_paths = ['data/bingo/advancements', 'data/bingo/functions', 'data/bingo/functions/load',
             'data/bingo/functions/tick', 'data/minecraft/tags/functions',]

print('Path:', main_path)

names = ['00.json', '10.json', '20.json', '30.json', '40.json',
         '01.json', '11.json', '21.json', '31.json', '41.json',
         '02.json', '12.json', '22.json', '32.json', '42.json',
         '03.json', '13.json', '23.json', '33.json', '43.json',
         '04.json', '14.json', '24.json', '34.json', '44.json']
parents = ['start', '00', '10', '20', '30',
           'start', '01', '11', '21', '31',
           'start', '02', '12', '22', '32',
           'start', '03', '13', '23', '33',
           'start', '04', '14', '24', '34']
adv = []

# ---bank search---

print('Getting advancements...')

# getting available
for file in os.listdir(sou_path):
    adv.append(file)

print(len(adv), 'advancements found. Selecting...')

# picking 25
for i in range(25):
    j = random.randint(0, len(adv) - 1)
    used = adv.pop(j)
    shutil.copy(os.path.join(sou_path, used), os.path.join(dest_path, names[i]))
    with fileinput.FileInput(os.path.join(dest_path, names[i]), inplace=True, backup='.bak') as file:
        for line in file:
            print(line.replace('~', parents[i]), end='')
    os.remove(os.path.join(dest_path, names[i] + '.bak'))

print('Zipping files...')

pack_zip = zipfile.ZipFile('bingo' + str(int(time.time())) + '.zip', 'w')

pack_zip.write('pack.mcmeta')
for a_path in zip_paths:
    for file in os.listdir(a_path):
        pack_zip.write(os.path.join(a_path, file))

pack_zip.close()

input('Finished! (ENTER to exit...)')
    
    
    
